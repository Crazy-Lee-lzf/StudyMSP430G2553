/*
 * shumaguan.h
 *
 *  Created on: 2024��3��22��
 *      Author: Administrator
 */

#ifndef SHUMAGUAN_H_
#define SHUMAGUAN_H_

void ShowTime(unsigned short *time, unsigned short shan);
void SMG_Init();
void Display();


#endif /* SHUMAGUAN_H_ */
