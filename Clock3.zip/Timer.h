/*
 * Timer.h
 *
 *  Created on: 2024��3��17��
 *      Author: Administrator
 */

#ifndef TIMER_H_
#define TIMER_H_

void Timer_Init();

#endif /* TIMER_H_ */
