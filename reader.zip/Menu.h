#ifndef __MENU_H
#define __MENU_H

void Menu_Init(void);
void Menu_main(void);
void Menu_cy(uint8_t page);
void Menu_my(uint8_t page);
void Menu_xs(uint8_t page);

#endif
