#ifndef TYPEDEF_H_
#define TYPEDEF_H_

typedef unsigned char uint8_t;
typedef unsigned int uint16_t;
typedef unsigned long uint32_t;
typedef unsigned long long uint64_t;

#endif
